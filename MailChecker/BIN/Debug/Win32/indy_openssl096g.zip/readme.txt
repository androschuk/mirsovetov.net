
OpenSSL libraries for Indy
***********************************
Copyright 2000-2002,
Gregor Ibic, gregor.ibic@intelicom.si
Intelicom d.o.o.
www.intelicom.si


This library is tested on Indy 9.0 and higher.
Support forum is avaiable at http://www.intelicom.si/forum

Please note, that you have to specify the usage of Indy and IndySSL with a copyright notice 
in your applications.

Comments and suggestions are welcome to my email.


